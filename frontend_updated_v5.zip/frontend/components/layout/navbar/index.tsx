import { AnimatedThemeToggler } from 'components/animated-theme-toggler';
import CategoriesMenu from './categories-menu';
import CartModal from 'components/cart/modal';
import LogoSquare from 'components/logo-square';
import { NavbarUserControl } from './user-control';
import { getMenu } from 'lib/shopify';
import { Menu } from 'lib/shopify/types';
import Link from 'next/link';
import { Suspense } from 'react';
import MobileMenu from './mobile-menu';
import Search, { SearchSkeleton } from './search';

const { SITE_NAME } = process.env;

export async function Navbar() {
  const menu = await getMenu('next-js-frontend-header-menu');

  return (
    <nav className="relative z-50 border-b border-neutral-500/60 mb-6 flex items-center justify-between p-4 lg:px-6">
      <div className="block flex-none md:hidden">
        <Suspense fallback={null}>
          <MobileMenu menu={menu} />
        </Suspense>
      </div>
      <div className="flex w-full items-center">
        <div className="flex w-full md:w-1/3">
          <Link
            href="/"
            prefetch={true}
            className="mr-2 flex w-full items-center justify-center md:w-auto lg:mr-6"
          >
            <LogoSquare />
            <div className="ml-2 flex-none text-sm font-medium uppercase md:hidden lg:block">
              {SITE_NAME}
            </div>
          </Link>
          {menu.length ? <CategoriesMenu menu={menu} /> : null}
        </div>
        <div className="hidden justify-center md:flex md:w-1/3">
          <Suspense fallback={<SearchSkeleton />}>
            <Search />
          </Suspense>
        </div>
        <div className="flex justify-end gap-x-4 md:w-1/3 items-center">
          <Suspense fallback={null}>
            <NavbarUserControl />
          </Suspense>
          <div className="transition-all duration-300 ease-in-out hover:translate-y-1">
            <AnimatedThemeToggler className="!text-white" />
          </div>
          <div className="transition-all duration-300 ease-in-out hover:translate-y-1">
            <CartModal />
          </div>
        </div>
      </div>

    </nav>
  );
}
