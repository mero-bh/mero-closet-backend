import { getCollectionProducts } from 'lib/shopify';
import Link from 'next/link';
import { CarouselClient } from './carousel-client';
import { GridTileImage } from './grid/tile';

export async function Carousel() {
  // Collections that start with `hidden-*` are hidden from the search page.
  const products = await getCollectionProducts({ collection: 'new-collections' });

  if (!products?.length) return null;

  // Purposefully duplicating products to make the carousel loop and not run out of products on wide screens.
  const carouselProducts = [...products, ...products, ...products].reverse();

  return (
    <CarouselClient>
      {carouselProducts.map((product, i) => (
        <li
          key={`${product.handle}${i}`}
          className="relative aspect-square h-[30vh] max-h-[275px] w-2/3 max-w-[475px] flex-none snap-start md:w-1/3"
        >
          <Link href={`/product/${product.handle}`} className="relative h-full w-full">
            <GridTileImage
              alt={product.title}
              label={{
                title: product.title,
                amount: product.priceRange.maxVariantPrice.amount,
                currencyCode: product.priceRange.maxVariantPrice.currencyCode
              }}
              src={product.featuredImage?.url}
              fill
              sizes="(min-width: 1024px) 25vw, (min-width: 768px) 33vw, 50vw"
            />
          </Link>
        </li>
      ))}
    </CarouselClient>
  );
}
