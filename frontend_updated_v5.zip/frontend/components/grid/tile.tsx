import clsx from 'clsx';
import Image from 'next/image';
import Label from '../label';

export function GridTileImage({
  isInteractive = true,
  active,
  label,
  ...props
}: {
  isInteractive?: boolean;
  active?: boolean;
  label?: {
    title: string;
    amount: string;
    currencyCode: string;
    position?: 'bottom' | 'center';
  };
} & React.ComponentProps<typeof Image>) {
  return (
    <div
      className={clsx(
        'group flex h-full w-full items-center justify-center overflow-hidden rounded-md border bg-white hover:border-border-hover ',
        {
          relative: label,
          'border-2 border-blue-600': active,
          'border-neutral-200 dark:border-neutral-800': !active
        }
      )}
    >
      {props.src ? (
        props.src.toString().endsWith('.mp4') ? (
          <video
            src={props.src as string}
            autoPlay
            loop
            muted
            playsInline
            className={clsx('relative h-full w-full object-cover rounded-md', {
              'transition duration-300 ease-in-out group-hover:scale-105': isInteractive
            })}
          />
        ) : (
          <Image
            className={clsx('relative h-full w-full object-cover rounded-md', {
              'transition duration-300 ease-in-out group-hover:scale-105': isInteractive
            })}
            {...props}
            unoptimized={true} // Avoids Next.js server timeouts with external images
          />
        )
      ) : null}
      {label ? (
        <Label
          title={label.title}
          amount={label.amount}
          currencyCode={label.currencyCode}
          position={label.position}
        />
      ) : null}
    </div>
  );
}
